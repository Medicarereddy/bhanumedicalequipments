BHANU MEDICAL EQUIPMENTS — FREE WEBSITE STARTER

Files:
- index.html: complete responsive website. No paid software or build tools required.

Business details included:
- Name: Bhanu Medical Equipments
- Phone/WhatsApp: +91 76192 83190
- Location: Devanahalli, Bengaluru, Karnataka
- Services: Oxygen concentrators, CPAP/BiPAP, hospital beds, wheelchairs, walkers, suction machines, DVT machines and home healthcare.

FREE PUBLISHING STEPS (GitHub Pages):
1. On a computer or phone browser, create/sign in to a free account at https://github.com/
2. Create a new public repository named: bhanu-medical-equipments
3. Upload index.html from this folder. (README.txt is optional.)
4. Open the repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish. Your site will be available at a free address similar to:
   https://YOUR-USERNAME.github.io/bhanu-medical-equipments/
   Replace YOUR-USERNAME with your actual GitHub username. The exact URL depends on your account and repository.
7. Open the published address on your phone and test the Call and WhatsApp buttons.

IMPORTANT:
- This is a ready-to-publish website file, not yet a live website. Publishing requires you to complete the hosting steps in your account.
- The address is currently listed as Devanahalli, Bengaluru, Karnataka; add a full shop address only if you want it public.
- Please test the phone number and WhatsApp link before sharing.
- Prices, stock, delivery, opening hours and guarantees are not claimed on the site; confirm them directly with customers.
- GitHub Pages currently offers free static-site hosting for public repositories; service terms can change.
